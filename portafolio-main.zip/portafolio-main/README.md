# Portafolio

**Tecnologías utilizadas en el proyecto:**  
<img src="https://img.icons8.com/color/344/html-5--v1.png" alt="html" width="50"/>
<img src="https://img.icons8.com/color/344/css3.png" alt="css" width="50"/>
<img src="https://img.icons8.com/color/344/javascript--v1.png" alt="JavaScript" width="50"/>

---

![portafolio-presentacion](https://user-images.githubusercontent.com/110046283/202334878-7ce721f1-db39-4388-bc39-8f9d141015a3.png)

---

[**Link del sitio web** ✌](https://mariana-am-portafolio.netlify.app/)
---
